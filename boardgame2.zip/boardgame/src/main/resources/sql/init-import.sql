
INSERT INTO
    `user` (`name`, `email`, `password`, `birthday`, `cell_Phone`, `gender`)
VALUES
    ('TestUser1', 'test1@test.com', 'test1234', now(), '010-1234-5678', 'MALE');